import 'package:PiliPlus/common/skeleton/skeleton.dart';
import 'package:PiliPlus/common/style.dart';
import 'package:material_ui/material_ui.dart';

class MediaPgcSkeleton extends StatefulWidget {
  const MediaPgcSkeleton({super.key});

  @override
  State<MediaPgcSkeleton> createState() => _MediaPgcSkeletonState();
}

class _MediaPgcSkeletonState extends State<MediaPgcSkeleton> {
  @override
  Widget build(BuildContext context) {
    final bgColor = ColorScheme.of(context).onInverseSurface;
    return Skeleton(
      child: Padding(
        padding: const .symmetric(horizontal: Style.safeSpace, vertical: 5),
        child: Row(
          children: [
            Container(
              width: 111,
              height: 148,
              decoration: BoxDecoration(
                borderRadius: const .all(Radius.circular(6)),
                color: bgColor,
              ),
            ),
            const SizedBox(width: 10),
            Expanded(
              child: SizedBox(
                height: 148,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Container(
                      color: bgColor,
                      width: 200,
                      height: 20,
                      margin: const EdgeInsets.only(bottom: 15),
                    ),
                    Container(
                      color: bgColor,
                      width: 150,
                      height: 13,
                      margin: const EdgeInsets.only(bottom: 5),
                    ),
                    Container(
                      color: bgColor,
                      width: 150,
                      height: 13,
                      margin: const EdgeInsets.only(bottom: 5),
                    ),
                    Container(
                      color: bgColor,
                      width: 150,
                      height: 13,
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
